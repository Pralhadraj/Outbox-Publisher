package com.infinite.publisher.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import java.util.*;

import javax.persistence.ForeignKey;



@Entity
@Table(name = "orders")
public class Order {
	
    @Id
    @GeneratedValue    
    @Column(name = "order_id")
    private Integer order_id;
    
    @Column(name = "date")
    private Double date;
    
    @Column(name = "purchaser_id")
    private Integer purchaser_id;
    
    @Column(name = "lineitems")
    private List<LineItems> lineitems;
    
    @Column(name = "total_price")
    private Integer total_price;

	public Integer getOrder_id() {
		return order_id;
	}

	public void setOrder_id(Integer order_id) {
		this.order_id = order_id;
	}

	public Double getDate() {
		return date;
	}

	public void setDate(Double date) {
		this.date = date;
	}

	public Integer getPurchaser_id() {
		return purchaser_id;
	}

	public void setPurchaser_id(Integer purchaser_id) {
		this.purchaser_id = purchaser_id;
	}

	

	public List<LineItems> getLineitems() {
		return lineitems;
	}

	public void setLineitems(List<LineItems> lineitems) {
		this.lineitems = lineitems;
	}

	public Integer getTotal_price() {
		return total_price;
	}

	public void setTotal_price(Integer total_price) {
		this.total_price = total_price;
	}
    


    
}

