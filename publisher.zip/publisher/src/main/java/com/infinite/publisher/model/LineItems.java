package com.infinite.publisher.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import antlr.collections.List;

@Entity
@Table(name = "LineItems")
public class LineItems {
	
    @Id
    @GeneratedValue
    @Column(name = "id")
    private Integer id;
    
    @Column(name = "order_id")
    private Integer order_id;
    
    @Column(name = "purchaser_id")
    private Integer purchaser_id;
    
    @Column(name = "Items")
    private List Items;
    
    @Column(name = "Total_Price")
    private Integer Total_Price;



 public LineItems(){
	 
 }



public Integer getId() {
	return id;
}



public void setId(Integer id) {
	this.id = id;
}



public Integer getOrder_id() {
	return order_id;
}



public void setOrder_id(Integer order_id) {
	this.order_id = order_id;
}



public Integer getPurchaser_id() {
	return purchaser_id;
}



public void setPurchaser_id(Integer purchaser_id) {
	this.purchaser_id = purchaser_id;
}



public List getItems() {
	return Items;
}



public void setItems(List items) {
	Items = items;
}



public Integer getTotal_Price() {
	return Total_Price;
}



public void setTotal_Price(Integer total_Price) {
	Total_Price = total_Price;
}
 
}
