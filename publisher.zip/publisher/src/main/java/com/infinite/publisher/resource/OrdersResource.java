package com.infinite.publisher.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.publisher.model.Order;
import com.infinite.publisher.repository.OrdersRepository;

@RestController
@RequestMapping(value =  "/rest/orders")
public class OrdersResource {
	 	@Autowired
	    OrdersRepository ordersRepository;
	
	@GetMapping(value = "/")
    public java.util.List<Order> getAll() {
        return ordersRepository.findAll();
    }

    @PostMapping(value = "/load")
    public java.util.List<Order> persist(@RequestBody final Order orders) {
        ordersRepository.save(orders);
        return ordersRepository.findAll();
        
    }
	

}
